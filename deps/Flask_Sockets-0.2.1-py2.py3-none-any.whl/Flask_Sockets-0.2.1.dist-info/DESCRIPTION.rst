Flask-Sockets
-------------

Elegant WebSockets for your Flask apps.


